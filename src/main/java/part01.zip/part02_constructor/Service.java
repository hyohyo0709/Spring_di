package part02_constructor;

public interface Service {
	public void prn1();
	public void prn2();
	public void prn3();
}
